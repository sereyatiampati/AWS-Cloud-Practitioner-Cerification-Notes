
myFruitList =["apple", "banana", "cherry"]
# print(myFruitList)
# print(type(myFruitList))

# print(myFruitList[0])

myFinalanswerTuple =("apple", "banana", "pineapple") # tuple is a list that can't be changed
# print(myFinalanswerTuple)
# print(type(myFinalanswerTuple))

# myFinalanswerTuple[0]= "grapes" // throws an error because it can't be changed

myFruitDictionary = {
    "Akua" : "apple",
    "Saanvi" : "banana",
    "Paulo" : "pineapple"
}
# print(myFruitDictionary["Akua"])

myMixedTypeList= ["45", 45, 1.02, True, "The dog is on the bed"]

for item in myMixedTypeList:
    print("{} is of data type {}".format(item, type(item)))
    
    