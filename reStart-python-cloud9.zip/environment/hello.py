# print("Hello world!")
# print("Python has three numeric types: int, float and complex")

myValue=5j
# print(type(myValue))

# print(str(myValue) + " is of the data type " + str(type(myValue)))

mystring="this is my string"
# print(mystring)

name=input("What is your name?  ")

# print(name)
color = input("What is your favourite color?    ")
animal = input("What is your favourite animal?    ")

print("{}, you like a {} {}!".format(name, color, animal))

